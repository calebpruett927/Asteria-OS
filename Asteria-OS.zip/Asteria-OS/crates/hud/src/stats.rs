// HUD stats stubs
