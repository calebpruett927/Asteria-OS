// Painter stubs
