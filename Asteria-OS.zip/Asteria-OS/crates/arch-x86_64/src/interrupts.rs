// Interrupts stubs
