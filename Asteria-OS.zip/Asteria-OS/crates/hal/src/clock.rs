// Clock stubs
