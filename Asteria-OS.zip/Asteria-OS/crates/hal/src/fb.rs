// Framebuffer stubs
