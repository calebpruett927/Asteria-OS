// Logger stubs
