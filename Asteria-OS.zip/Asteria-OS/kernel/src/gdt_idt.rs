// GDT/IDT stubs (OS mode later)
