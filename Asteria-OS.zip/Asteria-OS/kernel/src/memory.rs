// Memory init stubs (OS mode later)
