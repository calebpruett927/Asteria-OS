// Panic handler lives in os_mode; devhost uses std.
