// Time stubs
