use xshell::*;
use anyhow::*;

fn main() -> Result<()> {
    let sh = Shell::new()?;
    sh.run("cargo build -p asteria-kernel --release")?;
    // TODO: assemble UEFI image into dist/asteria-uefi.img
    Ok(())
}
