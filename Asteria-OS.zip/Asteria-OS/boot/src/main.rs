// devhost stub; replace with UEFI bootloader path later.
fn main() {
    println!("Asteria-boot (devhost stub). In OS mode, this crate builds the UEFI/BIOS boot image.");
}
